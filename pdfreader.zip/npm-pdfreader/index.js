const { extractTextFromPdf } = require("./processJson");

const pdfPath = process.argv[2];
if (!pdfPath) {
  console.log("Please provide the path to the PDF file as an argument.");
  console.log("Usage: node index.js <path_to_pdf>");
  process.exit(1);
}

extractTextFromPdf(pdfPath);


/*import { PdfReader } from "pdfreader";
import fs from "fs";

function extractTextFromPdf(pdfPath) {
  const pdfReader = new PdfReader();
  const lines = [];

  pdfReader.parseFileItems(pdfPath, function (err, item) {
    if (err) {
      console.error("Error:", err);
    } else if (!item) {
      // End of file
      const jsonData = JSON.stringify(lines, null, 2); // Convert the lines array to JSON format
      fs.writeFileSync("output.json", jsonData, "utf8"); // Save the JSON data to a file named "output.json"
      console.log("PDF parsing completed and data saved to output.json.");
    } else if (item.text) {
      // Collect text from each item
      lines.push(item.text);
    }
  });
}

const pdfPath = process.argv[2];
if (!pdfPath) {
  console.log("Please provide the path to the PDF file as an argument.");
  console.log("Usage: node index.js <path_to_pdf>");
  process.exit(1);
}

extractTextFromPdf(pdfPath);*/

/*import { PdfReader } from "pdfreadesr";

new PdfReader().parseFileItems("test/sample-table.pdf", (err, item) => {
  if (err) console.error("error:", err);
  else if (!item) console.warn("end of file");
  else if (item.text) console.log(item.text);
});


export { PdfReader } from "./PdfReader.js";
export { Rule } from "./Rule.js";
export * as LOG from "./lib/LOG.js";
import * as parseTableExports from "./lib/parseTable.js";
export const parseTable = Object.assign(
  parseTableExports.parseTable,
  parseTableExports
);
import * as parseColumnsExports from "./lib/parseColumns.js";
export const parseColumns = Object.assign(
  parseColumnsExports.parseColumns,
  parseColumnsExports
);
export { SequentialParser } from "./lib/SequentialParser.js"; // experimental
export { TableParser } from "./lib/TableParser.js";
export { ColumnsParser } from "./lib/ColumnsParser.js";*/
