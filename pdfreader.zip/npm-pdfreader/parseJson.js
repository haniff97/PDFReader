import { PdfReader } from "pdfreader";
import fetch from "node-fetch";
import fs from "fs";

async function extractDataFromPdf(pdfPath) {
  const jsonData = [];

  new PdfReader().parseFileItems(pdfPath, (err, item) => {
    if (err) {
      console.error("Error parsing PDF:", err);
      return;
    }

    // Push all text items into the array
    if (item && item.text) {
      jsonData.push(item.text);
    }
  });

  setTimeout(() => {
    console.log("Parsed JSON data:");
    console.log(jsonData);

    // Call a function to process the JSON data further if needed
    processData(jsonData);
  }, 2000); // Wait for 2 seconds to allow the PDF parsing to complete
}

// Rest of the code remains unchanged...

// Call the function to pick one PDF file from the "test" folder and extract data from it
pickOnePdfFromTestFolder();

// Function to pick one PDF file from the "test" folder
function pickOnePdfFromTestFolder() {
  const testFolderPath = "./test";

  // Read the contents of the "test" folder
  fs.readdir(testFolderPath, (err, files) => {
    if (err) {
      console.error("Error reading the 'test' folder:", err);
      return;
    }

    // Filter out the PDF files
    const pdfFiles = files.filter((file) => file.toLowerCase().endsWith(".pdf"));

    if (pdfFiles.length === 0) {
      console.log("No PDF files found in the 'test' folder.");
      return;
    }

    // Pick the first PDF file (you can modify this logic to choose a different PDF file)
    const selectedPdf = pdfFiles[0];

    // Call the function to extract data from the selected PDF
    const pdfFilePath = `${testFolderPath}/${selectedPdf}`;
    extractDataFromPdf(pdfFilePath);
  });
}

// Function to process the parsed JSON data further
function processData(jsonData) {
  // Slice the array starting from index 58 to get elements from line 59 onwards
  const dynamicData = jsonData.slice(57);

  // Use destructuring assignment to assign elements to variables
  const [
    name1,
    name2,
    code,
    date1,
    date2,
    assetCode,
    assetType,
    quantity,
    // ... and so on, continue the list for all elements from line 59 onwards
  ] = dynamicData;

  // Write the assigned variables to a JSON file
  const assignedVariables = {
    name1,
    name2,
    code,
    date1,
    date2,
    assetCode,
    assetType,
    quantity,
    // ... and so on, continue the properties for all elements from line 59 onwards
  };
  const outputJSON = JSON.stringify(assignedVariables, null, 2);
  fs.writeFileSync("output.json", outputJSON, "utf8");
  console.log("Assigned variables written to output.json");
}
